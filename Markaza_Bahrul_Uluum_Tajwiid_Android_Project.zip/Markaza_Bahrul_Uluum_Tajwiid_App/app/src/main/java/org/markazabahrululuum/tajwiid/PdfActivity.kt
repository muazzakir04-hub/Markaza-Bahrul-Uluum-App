package org.markazabahrululuum.tajwiid

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class PdfActivity : Activity() {
    private var renderer: PdfRenderer? = null
    private var descriptor: ParcelFileDescriptor? = null
    private var pageIndex = 0
    private lateinit var image: ImageView
    private lateinit var label: TextView
    private lateinit var previous: Button
    private lateinit var next: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 242))
        }
        val header = TextView(this).apply {
            text = "MARKAZA BAHRUL ULUUM  •  Kitaaba Tajwiidaa"
            setTextColor(Color.WHITE); textSize = 17f
            setBackgroundColor(Color.rgb(18, 60, 44)); gravity = Gravity.CENTER
            setPadding(12, 18, 12, 18)
        }
        image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        label = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 15f
            setPadding(8, 10, 8, 10)
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previous = Button(this).apply { text = "← Fuula duraa"; setOnClickListener { showPage(pageIndex - 1) } }
        next = Button(this).apply { text = "Fuula itti aanu →"; setOnClickListener { showPage(pageIndex + 1) } }
        controls.addView(previous, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(next, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header)
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(label)
        root.addView(controls)
        setContentView(root)
        try {
            val file = File(cacheDir, "kitaaba_tajwiidaa.pdf")
            if (!file.exists()) assets.open("kitaaba_tajwiidaa.pdf").use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(descriptor!!)
            showPage(0)
        } catch (e: Exception) {
            Toast.makeText(this, "PDF banamuu hin dandeenye: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage(index: Int) {
        val pdf = renderer ?: return
        if (index < 0 || index >= pdf.pageCount) return
        pageIndex = index
        val page = pdf.openPage(index)
        val width = (resources.displayMetrics.widthPixels * 0.95).toInt().coerceAtLeast(400)
        val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(500)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        image.setImageBitmap(bitmap)
        label.text = "Fuula ${index + 1} / ${pdf.pageCount}"
        previous.isEnabled = index > 0
        next.isEnabled = index < pdf.pageCount - 1
    }

    override fun onDestroy() {
        renderer?.close()
        descriptor?.close()
        super.onDestroy()
    }
}
